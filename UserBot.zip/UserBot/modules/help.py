from pyrogram import Client, filters
from pyrogram.types import Message

_modules_info = {}

# Информация о самом модуле help (ОБЯЗАТЕЛЬНО для команды .help)
__module_info__ = {
    'name': 'Справка',
    'commands': [
        '.help - Показывает список загруженных модулей.',
        '.help <название_модуля> - Показывает команды конкретного модуля.'
    ]
}

def init(app: Client, modules_info: dict):
    global _modules_info
    _modules_info = modules_info

    @app.on_message(filters.me & filters.command("help", prefixes="."))
    async def help_command(client: Client, message: Message):
        args = message.command
        
        if len(args) == 1:
            if not _modules_info:
                await message.edit_text("Модули не найдены или информация о них не загружена.")
                return

            response = "**📚 Ваши модули:**\n\n"
            sorted_modules = sorted(_modules_info.values(), key=lambda x: x.get('name', '').lower())
            
            for i, module_data in enumerate(sorted_modules):
                module_key = next((key for key, value in _modules_info.items() if value == module_data), None)
                display_name = module_data.get('name', module_key)
                response += f"{i+1}. `{display_name}`\n"
            
            response += "\nДля получения справки по модулю используйте `.help <название_модуля>`"
            await message.edit_text(response)

        elif len(args) == 2:
            target_module_arg = args[1].lower()
            
            found_module_data = None
            for key, data in _modules_info.items():
                if key.lower() == target_module_arg or data.get('name', '').lower() == target_module_arg:
                    found_module_data = data
                    break

            if found_module_data:
                display_name = found_module_data.get('name', target_module_arg)
                
                response = f"**⚙️ Команды модуля `{display_name}`:**\n\n"
                if found_module_data['commands']:
                    for cmd_desc in found_module_data['commands']:
                        response += f"`{cmd_desc}`\n"
                else:
                    response += "Команды для этого модуля не указаны."
                
                await message.edit_text(response)
            else:
                await message.edit_text(f"Модуль `{target_module_arg}` не найден или информация о нем отсутствует.")
        else:
            await message.edit_text("Неверное использование. Использование: `.help` или `.help <название_модуля>`")


