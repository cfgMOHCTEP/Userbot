from pyrogram import Client
import importlib
import os
import sys

# --- Переменная для хранения информации о модулях ---
loaded_modules_info = {}
# --- Конец переменной ---

# Твои API ID и API Hash (ОБЯЗАТЕЛЬНО проверь, что это ТВОИ ДАННЫЕ!)
API_ID = 28732325
API_HASH = "fc72c471c4b39c42254c7e816dc731ff"

# Имя сессии (не меняй, если ты уже входил)
SESSION_NAME = "my_telegram_session"

# Создаем клиент Pyrogram
app = Client(SESSION_NAME, api_id=API_ID, api_hash=API_HASH)

# --- Функция для загрузки модулей ---
def load_modules():
    global loaded_modules_info
    modules_folder = "modules" 
    
    if not os.path.exists(modules_folder):
        print(f"Ошибка: Папка '{modules_folder}/' не найдена. Создайте ее и поместите туда модули.")
        return

    # Добавляем путь к папке modules в sys.path, чтобы importlib мог находить модули
    if modules_folder not in sys.path:
        sys.path.insert(0, modules_folder)

    modules_to_load_first = []
    help_module_filename = None

    # Разделяем модули на "обычные" и "help.py"
    for filename in os.listdir(modules_folder):
        if filename.endswith(".py") and not filename.startswith("__"):
            if filename == "help.py":
                help_module_filename = filename
            else:
                modules_to_load_first.append(filename)

    # Этап 1: Загружаем все модули, кроме help.py
    for filename in modules_to_load_first:
        module_name = filename[:-3]
        try:
            module = importlib.import_module(module_name)
            
            if hasattr(module, 'init'):
                module.init(app)

            if hasattr(module, '__module_info__') and isinstance(module.__module_info__, dict):
                info = module.__module_info__
                if 'name' in info and 'commands' in info and isinstance(info['commands'], list):
                    loaded_modules_info[module_name] = info
                    print(f"Модуль '{info['name']}' ({module_name}) загружен успешно.")
                else:
                    print(f"Предупреждение: Модуль '{module_name}' не имеет полного __module_info__.")
            else:
                print(f"Модуль '{module_name}' загружен успешно (без __module_info__).")

        except Exception as e:
            print(f"Ошибка при загрузке модуля '{module_name}': {e}")
            import traceback
            traceback.print_exc()

    # Этап 2: Загружаем модуль help.py (теперь, когда информация о других модулях собрана)
    if help_module_filename:
        try:
            module_name = help_module_filename[:-3]
            help_module = importlib.import_module(module_name)
            if hasattr(help_module, 'init'):
                help_module.init(app, loaded_modules_info) # Передаем собранную информацию
                if hasattr(help_module, '__module_info__') and isinstance(help_module.__module_info__, dict):
                    info = help_module.__module_info__
                    if 'name' in info and 'commands' in info and isinstance(info['commands'], list):
                        loaded_modules_info[module_name] = info
                        print(f"Модуль '{info['name']}' ({module_name}) загружен успешно.")
                    else:
                        print(f"Предупреждение: Модуль 'help' не имеет полного __module_info__.")
            else:
                print(f"Модуль 'help' загружен, но не имеет функции init.")
        except Exception as e:
            print(f"Ошибка при загрузке модуля 'help': {e}")
            import traceback
            traceback.print_exc()

# --- Запуск бота ---
if __name__ == "__main__":
    print("Бот запускается...")
    load_modules()
    app.run()
    print("Бот остановлен.")

